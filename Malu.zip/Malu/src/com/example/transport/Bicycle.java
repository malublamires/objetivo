package com.example.transport;

public class Bicycle implements Transport {
    @Override
    public void ride() {
        System.out.println("Andando de bike!");
    }
}
