package com.example.transport;

public class Main {
    public static void main(String[] args) {
        TransportFactory electricFactory = new ElectricTransportFactory();
        
        Transport electricScooter = electricFactory.createScooter();
        Transport electricBike = electricFactory.createBike();
        
        electricScooter.ride();
        electricBike.ride();

        TransportFactory humanPoweredFactory = new HumanPoweredTransportFactory();
        
        Transport bicycle = humanPoweredFactory.createBike();
        Transport rollerSkates = new RollerSkates();
        Transport skateboard = new Skateboard();

        bicycle.ride();
        rollerSkates.ride();
        skateboard.ride();
    }
}
