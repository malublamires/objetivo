package com.example.transport;

public class Skateboard implements Transport {
    @Override
    public void ride() {
        System.out.println("Andando de skateboard!");
    }
}
